#ifndef INTERRUPT_H__
#define INTERRUPT_H__

void rt_hw_irq_enable(int vector);
void rt_hw_irq_disable(int vector);

#endif
